# Postal Navideña

Este ZIP contiene:
- `postal-navidad-gael-V5.html`: Tu postal navideña lista.
- `README.md`: Instrucciones para publicar.

## Publicar en Netlify
1. Ve a [https://app.netlify.com/drop](https://app.netlify.com/drop).
2. Arrastra el archivo HTML.
3. Obtendrás un enlace público inmediato.

## Publicar en GitHub Pages
1. Crea un repositorio en GitHub.
2. Sube el archivo HTML.
3. Activa GitHub Pages en la configuración.
4. Tu URL será algo como:
   `https://tuusuario.github.io/postal-navidad-gael-V5.html`
